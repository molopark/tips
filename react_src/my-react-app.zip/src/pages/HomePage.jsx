// src/pages/HomePage.jsx

// React에서 컴포넌트를 만들 때 필요한 것들과 상태(State)를 관리하는 'useState',
// 컴포넌트가 화면에 나타났을 때 어떤 작업을 할지 정하는 'useEffect'를 가져와요.
import React, { useState, useEffect } from 'react';
// 우리가 만든 서버 호출 함수들을 가져와요.
import { fetchUserData, createPost } from '../api/apiService';
// 우리가 만든 예쁜 Button 컴포넌트를 가져와요.
import Button from '../components/Button';

// HomePage 컴포넌트를 만들어요.
const HomePage = () => {
  // 'userData'는 사용자 정보를 저장할 곳이고, 'setUserData'는 그 정보를 바꿀 때 사용해요.
  // 'null'은 처음에는 아무 정보도 없다는 뜻이에요.
  const [userData, setUserData] = useState(null);
  // 'loading'은 서버에서 데이터를 가져오는 중인지 아닌지를 알려줘요.
  const [loading, setLoading] = useState(true);
  // 'error'는 서버 통신 중 문제가 생겼을 때 에러 메시지를 저장할 곳이에요.
  const [error, setError] = useState(null);
  // 'newPostContent'는 새로운 게시글 내용을 입력받을 곳이에요.
  const [newPostContent, setNewPostContent] = useState('');
  // 'postStatus'는 게시글 전송 결과를 알려줄 곳이에요.
  const [postStatus, setPostStatus] = useState('');

  // 컴포넌트가 화면에 처음 나타났을 때 사용자 정보를 가져오는 작업을 해요.
  // 'useEffect'는 특정 상황(여기서는 컴포넌트가 처음 나타날 때)에만 코드를 실행하게 해줘요.
  useEffect(() => {
    const getUserData = async () => {
      try {
        setLoading(true); // 데이터를 가져오기 시작했으니 로딩 중이라고 알려줘요.
        const data = await fetchUserData('123'); // '123'번 사용자 정보를 가져와요.
        setUserData(data); // 가져온 정보를 'userData'에 저장해요.
      } catch (err) {
        setError('사용자 정보를 가져오는 데 실패했습니다.'); // 에러가 발생하면 메시지를 저장해요.
        console.error(err);
      } finally {
        setLoading(false); // 데이터 가져오기가 끝났으니 로딩이 아니라고 알려줘요.
      }
    };

    getUserData(); // 함수를 바로 실행해서 사용자 정보를 가져와요.
  }, []); // []는 이 작업이 컴포넌트가 화면에 처음 나타났을 때 딱 한 번만 실행된다는 뜻이에요.

  // '게시글 보내기' 버튼을 눌렀을 때 실행될 함수예요.
  const handlePostSubmit = async () => {
    if (!newPostContent.trim()) { // 입력칸이 비어있으면 경고 메시지를 보여줘요.
      setPostStatus('게시글 내용을 입력해주세요!');
      return;
    }
    setPostStatus('게시글 전송 중...'); // 전송 중이라고 알려줘요.
    try {
      // 서버에 새로운 게시글을 보내요.
      const result = await createPost({ title: '새 게시글', content: newPostContent });
      setPostStatus(`게시글이 성공적으로 전송되었습니다! ID: ${result.id}`); // 성공 메시지를 보여줘요.
      setNewPostContent(''); // 입력칸을 비워요.
    } catch (err) {
      setPostStatus('게시글 전송에 실패했습니다.'); // 실패 메시지를 보여줘요.
      console.error(err);
    }
  };

  // 화면에 보여줄 내용을 만들어요.
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-2xl">
        <h1 className="text-4xl font-extrabold text-center text-gray-800 mb-8">
          환영합니다! ✨
        </h1>

        {/* 사용자 정보 섹션 */}
        <div className="mb-8 p-6 bg-blue-50 rounded-lg shadow-inner">
          <h2 className="text-2xl font-semibold text-blue-700 mb-4">내 정보</h2>
          {loading && <p className="text-gray-600">사용자 정보를 불러오는 중...</p>}
          {error && <p className="text-red-500">{error}</p>}
          {userData && (
            <div className="text-gray-700">
              <p><strong>이름:</strong> {userData.name}</p>
              <p><strong>이메일:</strong> {userData.email}</p>
              <p><strong>가입일:</strong> {new Date(userData.joinedDate).toLocaleDateString()}</p>
            </div>
          )}
        </div>

        {/* 게시글 작성 섹션 */}
        <div className="mb-8 p-6 bg-purple-50 rounded-lg shadow-inner">
          <h2 className="text-2xl font-semibold text-purple-700 mb-4">새 게시글 작성</h2>
          <textarea
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-transparent mb-4 resize-y"
            rows="4"
            placeholder="여기에 게시글 내용을 입력하세요..."
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)} // 입력칸 내용이 바뀔 때마다 'newPostContent'를 업데이트해요.
          ></textarea>
          {/* 우리가 만든 Button 컴포넌트를 사용해요. */}
          <Button onClick={handlePostSubmit}>게시글 보내기</Button>
          {postStatus && <p className={`mt-4 text-center ${postStatus.includes('성공') ? 'text-green-600' : 'text-red-500'}`}>{postStatus}</p>}
        </div>

        {/* 다른 섹션이나 컴포넌트들을 여기에 추가할 수 있어요. */}
        <p className="text-center text-gray-500 mt-8">
          이 페이지는 React와 Tailwind CSS로 만들어졌습니다.
        </p>
      </div>
    </div>
  );
};

// 다른 파일에서 이 HomePage 컴포넌트를 사용할 수 있도록 내보내요.
export default HomePage;

// src/App.jsx

// React에서 컴포넌트를 만들 때 필요한 것들을 가져와요.
import React from 'react';
// 우리가 만든 HomePage 화면 컴포넌트를 가져와요.
import HomePage from './pages/HomePage';
// 전체 앱의 디자인을 위한 CSS 파일을 가져와요. (Tailwind CSS 기본 설정)
import './index.css'; // Vite가 자동으로 Tailwind CSS를 처리하도록 설정되어 있어요.

// App 컴포넌트를 만들어요. 이 컴포넌트가 우리 웹 앱의 가장 큰 부분이에요.
const App = () => {
  return (
    // HomePage 컴포넌트를 화면에 보여줘요.
    // 여기에 다른 페이지나 라우팅(화면 전환) 로직을 추가할 수 있어요.
    <HomePage />
  );
};

// 다른 파일에서 이 App 컴포넌트를 사용할 수 있도록 내보내요.
export default App;

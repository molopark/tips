// src/api/apiService.js

// 서버의 기본 주소를 정해요. 나중에 실제 서버 주소로 바꿔야 해요.
const BASE_URL = 'https://api.example.com'; 

// 사용자 정보를 서버에서 가져오는 함수예요.
// 'async'는 이 함수가 서버와 통신하는 동안 잠시 기다릴 수 있다는 뜻이에요.
export const fetchUserData = async (userId) => {
  try {
    // 서버의 특정 주소로 가서 사용자 정보를 요청해요.
    const response = await fetch(`${BASE_URL}/users/${userId}`);
    
    // 만약 서버에서 에러가 발생했다면 (예: 404 Not Found), 에러 메시지를 던져요.
    if (!response.ok) {
      throw new Error(`HTTP 오류! 상태: ${response.status}`);
    }
    
    // 서버에서 받은 응답을 JSON 형식으로 바꿔서 돌려줘요.
    const data = await response.json();
    return data;
  } catch (error) {
    // 서버 통신 중 문제가 생겼을 때 이곳으로 와서 에러를 알려줘요.
    console.error('사용자 데이터 가져오기 실패:', error);
    throw error; // 에러를 다시 던져서 이 함수를 호출한 곳에서 처리할 수 있게 해요.
  }
};

// 새로운 게시글을 서버에 보내는 함수예요.
export const createPost = async (postData) => {
  try {
    // 서버의 특정 주소로 게시글 데이터를 'POST' 방식으로 보내요.
    const response = await fetch(`${BASE_URL}/posts`, {
      method: 'POST', // 데이터를 서버에 보낼 때 사용하는 방법이에요.
      headers: {
        'Content-Type': 'application/json', // 보내는 데이터가 JSON 형식이라고 알려줘요.
      },
      body: JSON.stringify(postData), // JavaScript 객체를 JSON 문자열로 바꿔서 보내요.
    });

    // 서버에서 에러가 발생했다면 에러 메시지를 던져요.
    if (!response.ok) {
      throw new Error(`HTTP 오류! 상태: ${response.status}`);
    }

    // 서버에서 받은 응답을 JSON 형식으로 바꿔서 돌려줘요.
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('게시글 생성 실패:', error);
    throw error;
  }
};

// 필요한 다른 서버 호출 함수들을 여기에 추가할 수 있어요.
// export const updateProduct = async (productId, productData) => { ... };

// src/main.jsx

// React 앱을 웹 브라우저에 연결하는 데 필요한 것들을 가져와요.
import React from 'react';
import ReactDOM from 'react-dom/client';
// 우리가 만든 가장 큰 App 컴포넌트를 가져와요.
import App from './App.jsx';
// Tailwind CSS를 사용하기 위한 기본 CSS 파일을 가져와요.
import './index.css';

// 웹페이지의 'root'라는 아이디를 가진 HTML 요소를 찾아서 React 앱을 그 안에 보여줄 준비를 해요.
ReactDOM.createRoot(document.getElementById('root')).render(
  // <React.StrictMode>는 개발 중에 문제가 없는지 확인해주는 도구예요.
  <React.StrictMode>
    <App /> {/* 우리가 만든 App 컴포넌트를 웹페이지에 보여줘요. */}
  </React.StrictMode>,
);

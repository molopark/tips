// src/components/Button.jsx

// React에서 컴포넌트를 만들 때 필요한 것들을 가져와요.
import React from 'react';

// Button 컴포넌트를 만들어요.
// 이 컴포넌트는 'children'(버튼 안의 글씨)과 'onClick'(버튼을 눌렀을 때 할 일)을 받아요.
const Button = ({ children, onClick }) => {
  return (
    // <button> 태그는 실제 웹페이지의 버튼을 만들어요.
    // Tailwind CSS 클래스를 사용해서 버튼을 예쁘게 꾸며요.
    // 'onClick' 이벤트는 버튼이 클릭될 때 'onClick' 함수를 실행해요.
    <button
      className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
      onClick={onClick}
    >
      {children} {/* 버튼 안에 들어갈 글씨나 다른 요소들이에요 */}
    </button>
  );
};

// 다른 파일에서 이 Button 컴포넌트를 사용할 수 있도록 내보내요.
export default Button;

package com.molo.reactapi.app.hello;

import org.springframework.web.bind.annotation.GetMapping; // GET 요청을 처리할 때 사용
import org.springframework.web.bind.annotation.RequestParam; // URL 파라미터를 받을 때 사용
import org.springframework.web.bind.annotation.RestController; // REST API 컨트롤러임을 나타냄

import lombok.extern.slf4j.Slf4j;

// 이 클래스가 REST API를 처리하는 컨트롤러임을 Spring에게 알려줍니다.
// @RestController는 @Controller와 @ResponseBody를 합친 것으로,
// 메서드의 반환값이 웹 응답의 본문(Body)으로 직접 전송됨을 의미합니다.
@RestController
@Slf4j
public class HelloController {

    // "/api/hello" 경로로 GET 요청이 오면 이 메서드가 실행됩니다.
    // @GetMapping은 GET HTTP 메서드를 처리합니다.
    @GetMapping("/api/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
        // @RequestParam: URL에서 'name'이라는 파라미터 값을 받습니다.
        // 만약 'name' 파라미터가 없으면 기본값으로 "World"를 사용합니다.
        // 예시 URL: http://localhost:8080/api/hello?name=ReactUser

        log.debug("로그 debug - /api/hello");
        log.info("로그 info - /api/hello");
        // 클라이언트(프론트엔드)에게 보낼 메시지를 반환합니다.
        return String.format("Hello, %s! From Spring Boot Backend!", name);
    }

    // "/api/message" 경로로 GET 요청이 오면 이 메서드가 실행됩니다.
    // 이 메서드는 사용자 정보 대신 간단한 메시지를 반환합니다.
    @GetMapping("/api/message")
    public String getMessage() {
        return "안녕하세요! Spring Boot 서버에서 보낸 메시지입니다. 😊";
    }
}

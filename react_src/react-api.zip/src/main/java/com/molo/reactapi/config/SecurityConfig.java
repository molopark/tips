package com.molo.reactapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

// 이 클래스가 Spring 보안 설정을 담당한다고 알려줍니다.
@Configuration
// 웹 보안 기능을 활성화합니다.
@EnableWebSecurity
public class SecurityConfig {

    // HTTP 보안 규칙을 정의하는 메서드입니다.
    // @Bean 어노테이션은 Spring이 이 메서드의 반환값을 빈(Bean)으로 등록하게 합니다.
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 모든 요청(request)에 대해 인증 없이 접근을 허용합니다.
            // 즉, 로그인 없이도 모든 페이지에 접근할 수 있게 합니다.
            .authorizeHttpRequests(authorize -> authorize
                .anyRequest().permitAll())
            // CSRF(Cross-Site Request Forgery) 보호 기능을 비활성화합니다.
            // REST API 서버에서는 보통 비활성화합니다.
            .csrf(csrf -> csrf.disable());

        // 설정된 보안 필터 체인을 반환합니다.
        return http.build();
    }
}
